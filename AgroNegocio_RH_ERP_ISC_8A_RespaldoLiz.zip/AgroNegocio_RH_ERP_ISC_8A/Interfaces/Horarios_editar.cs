﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgroNegocio_RH_ERP_ISC_8A.Interfaces
{
    public partial class Horarios_editar : Form
    {
        public Horarios_editar()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //DataGridViewRow renglon = new DataGridViewRow();
            //renglon.CreateCells(dataGridView1);

            //renglon.Cells["ID"] = 0;
            //renglon.Cells["Dia"] = 
        }

        private void Horarios_editar_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
