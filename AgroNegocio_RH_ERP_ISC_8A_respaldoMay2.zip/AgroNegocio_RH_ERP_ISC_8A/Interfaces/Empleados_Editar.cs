﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgroNegocio_RH_ERP_ISC_8A.Interfaces
{
    public partial class Empleados_Editar : Form
    {
        public Empleados_Editar()
        {
            InitializeComponent();
        }

        private void cbx_Edo_civil_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
